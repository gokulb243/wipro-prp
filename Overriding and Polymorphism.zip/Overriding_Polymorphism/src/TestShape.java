
public class TestShape {

	public static void main(String[] args) {
		Circle c=new Circle();
		Triangle t=new Triangle();
		Square s=new Square();
		c.draw();
		c.erase();
		t.draw();
		t.erase();
		s.draw();
		s.erase();
	}

}
