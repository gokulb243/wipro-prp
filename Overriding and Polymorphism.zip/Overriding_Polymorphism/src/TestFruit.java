
public class TestFruit {

	public static void main(String[] args) {
		Apple a=new Apple("apple", "sweet", "small");
		Orange o=new Orange("orange", "sour", "moderate");
		a.eat();
		o.eat();

	}

}
