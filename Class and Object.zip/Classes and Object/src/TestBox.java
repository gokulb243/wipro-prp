
public class TestBox {

	public static void main(String[] args) {
		Box b=new Box(10, 10, 10);
		System.out.println(b.volume());
	}

}
