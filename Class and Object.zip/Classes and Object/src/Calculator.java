
public class Calculator 
{

	public static int powerInt(int num1,int num2)
	{
		
		return (int)Math.pow((double)num1,(double)num2);
	}
	public static double powerDouble(double num1,double num2)
	{
		return Math.pow((double)num1,(double)num2);
	}
	
	
	
	
	public static void main(String[] args) 
	{
		System.out.println(Calculator.powerInt(2, 2));
		System.out.println(Calculator.powerDouble(2.0, 2.0));
		
	}

}
