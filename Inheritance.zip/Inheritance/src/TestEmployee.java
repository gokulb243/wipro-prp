
public class TestEmployee {

	public static void main(String[] args) 
	{
		Employee e=new Employee("gokul", 50000.00, 2021, "123672j28kj2");
		Person p=new Person("xxx");
		System.out.println(e.getName()+" "+e.getSalary()+" "+e.getYearOfJoining()+" "+e.getNationalInsuranceNo());
		System.out.println(e.getClass());
		System.out.println(p.getClass());

	}

}
