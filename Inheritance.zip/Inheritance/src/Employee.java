
public class Employee extends Person
{
	double salary;
	int yearOfJoining;
	String nationalInsuranceNo;
	public Employee(String name, double salary, int yearOfJoining, String nationalInsuranceNo) {
		super(name);
		this.salary = salary;
		this.yearOfJoining = yearOfJoining;
		this.nationalInsuranceNo = nationalInsuranceNo;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getYearOfJoining() {
		return yearOfJoining;
	}
	public void setYearOfJoining(int yearOfJoining) {
		this.yearOfJoining = yearOfJoining;
	}
	public String getNationalInsuranceNo() {
		return nationalInsuranceNo;
	}
	public void setNationalInsuranceNo(String nationalInsuranceNo) {
		this.nationalInsuranceNo = nationalInsuranceNo;
	}
	

}
