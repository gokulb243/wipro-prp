
public class Bird extends Animal
{
	public void eat()
	{
		System.out.println("bird eats");
	}
	public void sleep()
	{
		System.out.println("bird sleeps");
	}
	public void fly()
	{
		System.out.println("bird flies");
	}

}
