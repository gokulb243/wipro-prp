
public class Animal 
{
	public void eat()
	{
		System.out.println("animal eats");
	}
	public void sleep()
	{
		System.out.println("animal sleeps");
	}

}
