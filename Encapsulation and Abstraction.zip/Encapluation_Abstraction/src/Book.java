
public class Book extends Author
{
	String bookname;
	double price;
	int qtyInStock;
	public Book(String name, String email, char gender, String bookname, double price, int qtyInStock) {
		super(name, email, gender);
		this.bookname = bookname;
		this.price = price;
		this.qtyInStock = qtyInStock;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQtyInStock() {
		return qtyInStock;
	}
	public void setQtyInStock(int qtyInStock) {
		this.qtyInStock = qtyInStock;
	}
		
}
