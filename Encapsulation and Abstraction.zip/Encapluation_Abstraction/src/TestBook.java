
public class TestBook {

	public static void main(String[] args) {
		Book b=new Book("varma", "varma123@gmail.com", 'M', "get into real world", 200.00, 5);
		System.out.println("book details:");
		System.out.println(b.getBookname()+" "+b.getPrice()+" "+b.getQtyInStock());
		System.out.println("Author details:");
		System.out.println(b.getName()+" "+b.getEmail()+" "+b.getGender());
	}

}
