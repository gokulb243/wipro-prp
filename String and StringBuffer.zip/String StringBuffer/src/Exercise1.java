import java.util.*;
public class Exercise1 {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		String s1=new StringBuffer().reverse().toString();
		if(s.equals(s1))
		{
			System.out.println("palindrome");
		}
		else
		{
			System.out.println("not a palindrome");
		}
		
	}

}
