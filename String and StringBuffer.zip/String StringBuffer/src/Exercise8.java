import java.util.*;
public class Exercise8 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		String s1=new String();
		char a[]=s.toCharArray();
		for(int i=0;i<a.length;i++)
		{
			if(a[i]=='*')
			{
				a[i]=a[i+1]=a[i-1]=0;
			}
		}
		for(char x:a)
		{
			if(x!=0)
			{
				s1+=x;
			}
		}
		System.out.println(s1);
	

	}

}
