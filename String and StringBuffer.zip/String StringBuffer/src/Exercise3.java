import java.util.*;
public class Exercise3 {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		String s1="";
		for(int i=0;i<s.length();i++)
		{
			s1=s1+s.substring(0, 2);
		}
		System.out.println(s1);
	}
}
