import java.util.*;
public class Exercise6 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String s1=sc.next();
		String s2=sc.next();
		String[] a=new String[3];
		int j=0;
			if(s1.length()>s2.length())
			{
				a[1]=s1;
				a[0]=a[2]=s2;
				
			}
			else if(s2.length()>s1.length())
			{
				a[1]=s2;
				a[0]=a[2]=s1;
			}
		for(String x:a)
		{
			System.out.print(x);
		}
	}

}
