import java.util.*;
public class Exercise9 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String n="";
		String s=sc.next();
		String[] a=s.split(",");
		char[] a1=a[0].toCharArray();
		char[] a2=a[1].toCharArray();
		for(int i=0;i<a1.length;i++)
		{
			n+=a1[i];
			n+=a2[i];
		}
		System.out.println(n);
	}

}
