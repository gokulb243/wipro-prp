import java.util.*;
public class Exercise2 {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s1=sc.next();
		String []s2=s1.split(",");
		char a=s2[0].charAt(s2[0].length()-1);
		char b=s2[1].charAt(0);
		if(a==b)
		{
			System.out.println(s2[0]+s2[1].substring(1));
		}
		else
		{
			System.out.println(s2[0]+s2[1]);
		}
	}

}
