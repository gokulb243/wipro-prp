
public class Exercise16 {

	public static void main(String[] args) 
	{
		int i=1234;
		String s="";
		while(i>0)
		{
			int a=i%10;
			s=s+a;
			i=i/10;
		}
		System.out.println(Integer.parseInt(s));
	}

}
