import java.util.Scanner;
public class Exercise12 {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int factors=0;
		for(int i=1;i<=a;i++)
		{
			if(a%i==0)
			{
				factors++;
			}
		}
		if(factors==2)
		{
			System.out.println("prime number");
		}
		else
		{
			System.out.println("not a prime number");
		}
		
		
		

	}

}
