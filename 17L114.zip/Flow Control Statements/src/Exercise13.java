
public class Exercise13 {

	public static void main(String[] args) 
	{
		for(int j=10;j<99;j++)
		{
		int factors=0;
		for(int i=1;i<=j;i++)
		{
			if(j%i==0)
			{
				factors++;
			}
		}
		if(factors==2)
		{
			System.out.print(j+" ");
		}
		}
		
	}

}
