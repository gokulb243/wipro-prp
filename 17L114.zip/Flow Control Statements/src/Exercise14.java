import java.util.Scanner;

public class Exercise14 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int count=0;
		while(a>0)
		{
			count=count+(a%10);
			a=a/10;
		}
		System.out.println(count);
	}

}
