import java.util.Scanner;

public class Exercise7 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char a='a';
		if(Character.isLowerCase(a))
		{
			System.out.println(a+"->"+Character.toUpperCase(a));
		}
		else if(Character.isUpperCase(a))
		{
			System.out.println(a+"->"+Character.toLowerCase(a));
		}
		

	}

}
