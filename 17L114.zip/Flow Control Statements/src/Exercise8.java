import java.util.Scanner;

public class Exercise8 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char a=sc.next().charAt(0);
		
		if(Character.isLowerCase(a))
		{
			System.out.println("Invalid Code");
		}
		else
		{
			if(a=='R')
				System.out.println(a+"->Red");
			if(a=='B')
				System.out.println(a+"->Blue");
			if(a=='G')
				System.out.println(a+"->Green");
			if(a=='O')
				System.out.println(a+"->Orange");
			if(a=='Y')
				System.out.println(a+"->Yellow");
			if(a=='W')
				System.out.println(a+"->White");
		}

	}

}
