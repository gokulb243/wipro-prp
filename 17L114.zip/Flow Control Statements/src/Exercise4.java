import java.util.Scanner;
public class Exercise4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char a='a';
		char b='e';
		if(a>b)
		{
			System.out.println(b+","+a);
		}
		else if(b>a)
		{
			System.out.println(a+","+b);
		}

	}

}
