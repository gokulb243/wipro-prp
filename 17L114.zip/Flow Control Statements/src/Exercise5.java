import java.util.Scanner;
public class Exercise5 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char a='%';
		if(Character.isDigit(a))
		{
			System.out.println("digit");
		}
		else if(Character.isAlphabetic(a))
		{
			System.out.println("alphabet");
		}
		else
		{
			System.out.println("special character");
		}

	}

}
