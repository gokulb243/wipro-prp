import java.util.Scanner;

public class Exercise1a 
{
	public boolean lastDigit(int a,int b)
	{
		if(a<9&&b<9)
		{
			if(a==b)
			{
				return true;
			}	
			else
			{
				return false;
			}
				
		}
		else if((a<9)&&(b>9))
		{
			if(a==b%10)
			{
				return true;
			}	
			else
			{
				return false;
			}
		}
		else if(a>9&&b<9)
		{
			if(a%10==b)
			{
				return true;
			}	
			else
			{
				return false;
			}
		}
		else
		{
			if(a%10==b%10)
			{
				return true;
			}	
			else
			{
				return false;
			}
		}
		
	}

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		Exercise1a n=new Exercise1a();
		System.out.println(n.lastDigit(a, b));
	}

}
