import java.util.Arrays;

public class Exercise5 {

	public static void main(String[] args) {
		int a[]= {6,3,55,20,78,2,10};
		Arrays.sort(a);
		System.out.println("largest two numbers : "+a[a.length-1]+" , "+a[a.length-2]);
		System.out.println("smallest two numbers : "+a[0]+" , "+a[1]);

	}

}
