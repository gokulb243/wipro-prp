import java.util.Arrays;

public class Exercise6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {6,3,55,20,78,2,10};
		Arrays.sort(a);
		for(int x:a)
		{
			System.out.print(x+" ");
		}

	}

}
