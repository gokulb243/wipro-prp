import java.util.Arrays;

public class Exercise10 {

	public static void main(String[] args) {
		int a[]= {1,0,1,0,0,1,1};
		int b[]=new int[a.length];
		int j=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				b[j++]=a[i];
			}
		}
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2!=0)
			{
				b[j++]=a[i];
			}
		}
		for(int x:b)
		{
			System.out.print(x+" ");
		}
	}

}
