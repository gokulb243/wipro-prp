
public class Exercise4 {

	public static void main(String[] args) {
	int a[]= {65,66,67,68,69,70};
	
	for(int x:a)
	{
		System.out.print((char)x+" ");
	}

	}

}
