import java.util.*;
public class Exercise7 {

	public static void main(String[] args) 
	{
		int a[]= {6,3,55,20,78,78,2,10};
		Set<Integer> s=new LinkedHashSet<>();
		for(int i=0;i<a.length;i++)
		{
			s.add(a[i]);
		}
		for(int x:s)
		{
			System.out.print(x+" ");
		}
	}

}
