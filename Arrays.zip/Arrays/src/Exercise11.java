
public class Exercise11 {

	public static void main(String[] args)
	{
		int a[]= {1,1,2,4};
		int count=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==1||a[i]==4)
			{
				a[i]=0;
			}
		}
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==0)
			{
				count++;
			}
		}
		if(count==a.length)
			System.out.println("True");
		else
			System.out.println("False");
	}

}
