import java.util.*;

public class Exercise8 {

	public static void main(String[] args) {
		int[] a= {1,6,4,7,9};
		int count=0;
		List<Integer> al=new ArrayList<Integer>();
		for(int i=0;i<a.length;i++)
		{
			al.add(a[i]);
		}
		if(al.indexOf(6)<al.indexOf(7))
		{
			List<Integer> al1=new ArrayList<Integer>(al.subList(al.indexOf(6), al.indexOf(7)+1));
			al.removeAll(al1);
		}
		for(int x:al)
		{
			count+=x;
		}
		System.out.println(count);
	}

}
