import java.util.Arrays;
public class Exercise2 {

	public static void main(String[] args) 
	{
		int a[]= {6,3,55,20,78,2,10};
		Arrays.sort(a);
		System.out.println("maximum : "+a[a.length-1]);
		System.out.println("minimum : "+a[0]);
	}

}
