import java.util.*;
public class Exercise3 {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int a[]= {37,90,3,47,87,36,446,261};
		int b=sc.nextInt();
		int count=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==b)
			{
				System.out.println(i);
			}
			else
			{
				count++;
			}
		}
		if(count==a.length) {
			System.out.println(-1);
		}

	}

}
