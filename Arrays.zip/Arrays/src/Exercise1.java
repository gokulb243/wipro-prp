
public class Exercise1 {
	public static void main(String[] args) 
	{
		int a[]= {2,5,7,3,4,5};
		int sum=0;
		for(int x:a)
		{
			sum+=x;
		}
		System.out.println("sum : "+sum);
		System.out.println("average : "+sum/a.length);
	}

}
